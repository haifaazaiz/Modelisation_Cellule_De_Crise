import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Test_projet {
public static void main(String[] args) throws IOException {
	
	
	Personne p=new Personne("C://Users/Azaiez Hamed/Desktop/workspace/Projet de programmation/src/Personne.txt");
	//Medecin m=new Medecin();
	//Malade m1=new Malade();
	//Hopital h=new Hopital();
	//Navette n1=new Navette() ;
	//Hotel_confinement h1=new Hotel_confinement() ;
	//Pharmacie p1=new Pharmacie();
	//Organisation o=new Organisation();
	//Prevention p=new Prevention();
	Service s=new Service ();
	//s.envoi_ambulance(p);
	//s.service_etat_de_sante();
	//s.service_psy(p);
	//s.service_hotel_confinement();
	//System.out.println(s.service_bavette());
	//System.out.println(s.service_navette());
	//System.out.println(s.service_medicament());
     //s.aider(p);
	


		}
}


